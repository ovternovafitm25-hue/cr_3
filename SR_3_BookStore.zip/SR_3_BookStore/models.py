class Book:

    def __init__(
        self,
        id,
        title,
        author,
        price
    ):
        self.id = id
        self.title = title
        self.author = author
        self.price = price


class Order:

    def __init__(
        self,
        id,
        customer,
        book
    ):
        self.id = id
        self.customer = customer
        self.book = book


class User:

    def __init__(
        self,
        username
    ):
        self.username = username
