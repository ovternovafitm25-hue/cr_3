from app import app


def test_home():

    client = app.test_client()

    response = client.get("/")

    assert response.status_code == 200


def test_books():

    client = app.test_client()

    response = client.get("/books")

    assert response.status_code == 200


def test_api():

    client = app.test_client()

    response = client.get(
        "/api/books"
    )

    assert response.status_code == 200

