from models import Book

books = [
    Book(
        1,
        "Python",
        "Тарас Шевченко",
        500
    ),
    Book(
        2,
        "Flask",
        "Леся Українка",
        700
    )
]

orders = []
