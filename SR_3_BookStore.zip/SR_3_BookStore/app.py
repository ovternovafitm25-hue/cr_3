from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
from flask import session
from flask import jsonify

from database import books
from database import orders

from models import Book
from models import Order

app = Flask(__name__)

app.secret_key = "secret-key"

next_book_id = 3
next_order_id = 1


@app.route("/")
def index():

    return render_template(
        "index.html"
    )


@app.route("/books")
def book_list():

    return render_template(
        "books.html",
        books=books
    )


@app.route(
    "/books/create",
    methods=["GET", "POST"]
)
def create_book():

    global next_book_id

    if request.method == "POST":

        title = request.form[
            "title"
        ]

        author = request.form[
            "author"
        ]

        price = float(
            request.form["price"]
        )

        books.append(
            Book(
                next_book_id,
                title,
                author,
                price
            )
        )

        next_book_id += 1

        return redirect(
            url_for(
                "book_list"
            )
        )

    return render_template(
        "create_book.html"
    )


@app.route(
    "/books/<int:id>/edit",
    methods=["GET", "POST"]
)
def edit_book(id):

    book = next(
        (
            b
            for b in books
            if b.id == id
        ),
        None
    )

    if not book:
        return "404", 404

    if request.method == "POST":

        book.title = request.form[
            "title"
        ]

        book.author = request.form[
            "author"
        ]

        book.price = float(
            request.form["price"]
        )

        return redirect(
            url_for(
                "book_list"
            )
        )

    return render_template(
        "edit_book.html",
        book=book
    )


@app.route(
    "/books/<int:id>/delete"
)
def delete_book(id):

    book = next(
        (
            b
            for b in books
            if b.id == id
        ),
        None
    )

    if book:
        books.remove(book)

    return redirect(
        url_for(
            "book_list"
        )
    )


@app.route(
    "/order/<int:id>"
)
def order_book(id):

    global next_order_id

    book = next(
        (
            b
            for b in books
            if b.id == id
        ),
        None
    )

    orders.append(
        Order(
            next_order_id,
            "Оля",
            book
        )
    )

    next_order_id += 1

    return redirect(
        url_for(
            "orders_page"
        )
    )


@app.route("/orders")
def orders_page():

    return render_template(
        "orders.html",
        orders=orders
    )


# REST API

@app.route(
    "/api/books",
    methods=["GET"]
)
def api_books():

    return jsonify([
        {
            "id": b.id,
            "title": b.title,
            "author": b.author,
            "price": b.price
        }
        for b in books
    ])


@app.route(
    "/login",
    methods=["POST"]
)
def login():

    username = request.form[
        "username"
    ]

    session[
        "user"
    ] = username

    return "OK"


@app.route("/profile")
def profile():

    return jsonify({
        "user":
        session.get("user")
    })


if __name__ == "__main__":

    app.run(
        debug=True,
        port=5000
    )
